var btn= document.querySelector('#message');
btn.addEventListener("click", function(e){
    document.querySelector("#flash").style.display="none";
})